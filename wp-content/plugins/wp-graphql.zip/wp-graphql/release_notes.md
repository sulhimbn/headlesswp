## Release Notes



## Changelog

**Bump Type:** patch

### 🐛 Bug Fixes
- fix: Add fallback sizes to MediaItemSizeEnum when intermediate sizes are disabled ([#3433](https://github.com/wp-graphql/wp-graphql/pull/3433))

### 👏 Contributors

Thanks to the following contributors for making this release possible:

- [@jasonbahl](https://github.com/jasonbahl)
